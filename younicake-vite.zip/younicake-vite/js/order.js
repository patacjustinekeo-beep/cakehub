import { CFG } from "./config.js";
import { db, F } from "./firebase.js";
import { $, esc, peso, toast, loadMenu, requireLogin, friendly } from "./app.js";
const custom = document.body.dataset.page === "customize", f = $("#of");
const min = new Date(Date.now() + CFG.leadDays * 864e5).toISOString().slice(0, 10); f.date.min = min; f.date.value = min;
const opt = (n, l, list) => `<label>${l}<select name="${n}">${list.map((x, i) => `<option value="${i}">${esc(x[0])}${x[1] ? " (+" + peso(x[1]) + ")" : ""}</option>`).join("")}</select></label>`;
let menu = [];
(async () => {
  const u = await requireLogin(); f.name.value = u.displayName || "";
  if (custom) {
    $("#opts").innerHTML = [["size", "Size", CFG.sizes], ["flavor", "Flavor", CFG.flavors], ["filling", "Filling", CFG.fillings], ["frosting", "Frosting", CFG.frostings]].map(a => opt(...a)).join("") +
      `<fieldset><legend>Toppings (pick any)</legend>${CFG.toppings.map((t, i) => `<label class="chk"><input type="checkbox" name="top" value="${i}"> ${esc(t[0])} (+${peso(t[1])})</label>`).join("")}</fieldset>`;
  } else {
    menu = await loadMenu(); const want = new URLSearchParams(location.search).get("item");
    f.item.innerHTML = menu.map(m => `<option value="${esc(m.id)}"${m.id === want ? " selected" : ""}>${esc(m.name)} (${peso(m.price)})</option>`).join("");
  }
  calc();
})();
function calc() {
  let total = 0, summary = "", details = {};
  if (custom) {
    if (!f.size) return { total: 0 };
    const g = (n, a) => a[+f[n].value]; const tops = [...f.querySelectorAll("[name=top]:checked")].map(c => CFG.toppings[+c.value]);
    const parts = [g("size", CFG.sizes), g("flavor", CFG.flavors), g("filling", CFG.fillings), g("frosting", CFG.frostings), ...tops];
    total = parts.reduce((s, p) => s + p[1], 0);
    details = { size: parts[0][0], flavor: parts[1][0], filling: parts[2][0], frosting: parts[3][0], toppings: tops.map(t => t[0]).join(", ") || "None", message: f.cakemsg.value.trim() };
    summary = `Custom ${parts[0][0]} · ${parts[1][0]} · ${parts[2][0]} · ${parts[3][0]}`;
  } else {
    const m = menu.find(x => x.id === f.item.value); const q = Math.max(1, Math.min(50, +f.qty.value || 1));
    total = m ? m.price * q : 0; summary = m ? `${q} × ${m.name}` : ""; details = { item: m?.name || "", qty: q };
  }
  $("#total").textContent = peso(total); return { total, summary, details };
}
f.addEventListener("input", calc); f.addEventListener("change", calc);
f.method.onchange = () => { $("#addr").hidden = f.method.value !== "Delivery"; };
f.onsubmit = async e => {
  e.preventDefault(); const u = await requireLogin(), c = calc(); if (!c.total) return;
  const b = f.querySelector("button.btn:last-of-type"); b.disabled = true;
  try {
    await F.addDoc(F.collection(db, "orders"), { uid: u.uid, name: f.name.value.trim(), email: u.email, phone: f.phone.value.trim(), kind: custom ? "custom" : "menu", summary: c.summary, details: c.details, total: c.total, date: f.date.value, method: f.method.value, address: f.method.value === "Delivery" ? f.address.value.trim() : "", notes: f.notes.value.trim(), status: "Received", createdAt: F.serverTimestamp() });
    toast("Order sent! We will confirm in your chat."); setTimeout(() => location.href = "dashboard.html", 900);
  } catch (x) { toast(friendly(x)); b.disabled = false; }
};
