// EDIT THIS FILE to change business info, prices and options. No other code changes needed.
export const CFG = {
  firebase: {
    apiKey: "AIzaSyC1Z3l_7ypc6l60cgK2Ar3wTayc2qab02U",
    authDomain: "cakehub-86ee9.firebaseapp.com",
    projectId: "cakehub-86ee9",
    storageBucket: "cakehub-86ee9.firebasestorage.app",
    messagingSenderId: "795014255751",
    appId: "1:795014255751:web:c4e5e2813d7fb071efd422",
    measurementId: "G-85CJPHSVPP"
  },
  ownerEmail: "patacjustinekeo@gmail.com",
  brand: "younicake",
  tagline: "Cakes baked fresh, made your way.",
  phone: "0900 000 0000",
  address: "Balilihan, Bohol",
  hours: "Mon to Sat, 8am to 6pm",
  facebook: "https://www.facebook.com/profile.php?id=61584458616964",
  leadDays: 2,
  payment: "We confirm your total in the chat. You pay after we agree on the details.",
  sizes: [["6 inch (serves 6 to 8)", 950], ["8 inch (serves 10 to 14)", 1400], ["10 inch (serves 18 to 24)", 2200], ["2 tiers (serves 30+)", 3800]],
  flavors: [["Vanilla", 0], ["Chocolate", 0], ["Ube", 0], ["Mocha", 0], ["Strawberry", 0], ["Red velvet", 100]],
  fillings: [["Cream", 0], ["Chocolate fudge", 100], ["Caramel", 100], ["Fresh fruits", 150]],
  frostings: [["Buttercream", 0], ["Whipped cream", 0], ["Fondant (smooth, for designs)", 300]],
  toppings: [["Sprinkles", 50], ["Fresh fruits", 150], ["Edible flowers", 200], ["Cake topper", 120], ["Chocolate drip", 150]],
  starterMenu: [
    ["Birthday Cake", "Soft vanilla or chocolate layers with buttercream.", 950, "🎂"],
    ["Cupcake Box (6)", "Mix the flavors you like.", 480, "🧁"],
    ["Strawberry Shortcake", "Fresh cream, strawberries, light sponge.", 1100, "🍓"],
    ["Choco Fudge Cake", "Dark, moist and not too sweet.", 1000, "🍫"],
    ["Ube Cheesecake", "Creamy ube on a buttery crust.", 1200, "🥧"],
    ["Cake Slice", "One slice, for a small treat.", 120, "🍰"]
  ]
};
