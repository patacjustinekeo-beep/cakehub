import { CFG } from "./config.js";
import { auth, A, F, db, isOwner, whenUser } from "./firebase.js";
export const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const peso = n => "₱" + Number(n).toLocaleString("en-PH");
export const $ = s => document.querySelector(s);
export function toast(t) { const d = document.createElement("div"); d.className = "toast"; d.setAttribute("role", "status"); d.textContent = t; document.body.append(d); setTimeout(() => d.remove(), 3500); }
export const friendly = e => ({ "auth/invalid-credential": "Wrong email or password.", "auth/email-already-in-use": "This email already has an account. Try logging in.", "auth/weak-password": "Password needs at least 6 characters.", "auth/invalid-email": "That email does not look right.", "auth/popup-closed-by-user": "Google sign-in was closed.", "auth/unauthorized-domain": "This website address is not allowed yet. Add it in Firebase > Authentication > Settings > Authorized domains.", "permission-denied": "You do not have permission to do that. Please log in again." }[e.code] || "Something went wrong. Please try again.");
const page = document.body.dataset.page;
const links = [["index", "Home"], ["menu", "Menu"], ["customize", "Customize"], ["dashboard", "My orders & chat"]];
document.getElementById("hd").innerHTML = `<a class="logo" href="index.html">youni<b>cake</b></a><nav aria-label="Main">${links.map(([p, t]) => `<a href="${p}.html"${p === page ? " aria-current=page" : ""}>${t}</a>`).join("")}<a id="acct" class="btn sm" href="login.html">Log in</a></nav>`;
document.getElementById("ft").innerHTML = `<p><b>${esc(CFG.brand)}</b> · ${esc(CFG.tagline)}</p><p>${esc(CFG.hours)} · ${esc(CFG.address)} · ${esc(CFG.phone)}</p><p><a href="${CFG.facebook}" rel="noopener">Facebook</a> · <a href="dashboard.html#chat">Chat with us</a></p><p>© 2026 ${esc(CFG.brand)}</p>`;
A.onAuthStateChanged(auth, u => {
  const a = $("#acct"); if (!a) return;
  if (!u) { a.textContent = "Log in"; a.href = "login.html"; return; }
  if (isOwner(u)) { a.textContent = "Owner panel"; a.href = "owner.html"; } else { a.textContent = "Log out"; a.href = "#"; a.onclick = e => { e.preventDefault(); A.signOut(auth).then(() => location.href = "index.html"); }; }
});
export async function loadMenu(force) {
  const k = "yc_menu", c = !force && JSON.parse(sessionStorage.getItem(k) || "null");
  if (c && Date.now() - c.t < 120000) return c.d;
  let d = [];
  try { const s = await F.getDocs(F.collection(db, "menu")); d = s.docs.map(x => ({ id: x.id, ...x.data() })).filter(x => x.available !== false).sort((a, b) => a.name.localeCompare(b.name)); } catch (e) { }
  if (!d.length) d = CFG.starterMenu.map((m, i) => ({ id: "starter" + i, name: m[0], desc: m[1], price: m[2], emoji: m[3] }));
  sessionStorage.setItem(k, JSON.stringify({ t: Date.now(), d })); return d;
}
export const requireLogin = async () => { const u = await whenUser(); if (!u) location.href = "login.html?next=" + encodeURIComponent(location.pathname.split("/").pop() + location.search); return u; };
export const card = m => `<article class="card"><div class="e" aria-hidden="true">${esc(m.emoji || "🎂")}</div><h3>${esc(m.name)}</h3><p>${esc(m.desc)}</p><p class="price">${peso(m.price)}</p><a class="btn sm" href="order.html?item=${encodeURIComponent(m.id)}">Order this</a></article>`;
