# younicake Premium (Vite + npm)

Fast multi-page site built with Vite. Firebase is installed from npm (`firebase` package), with login, orders, owner and customer dashboards, live chat with photos, a menu and a "design your own cake" page.

## Run in GitHub Codespaces
```
unzip younicake-vite.zip && cd younicake-vite
npm install
npm run dev
```
Codespaces shows a pop-up for port **5173**. Click "Open in Browser".

## Build and deploy
```
npm run build      # makes the dist/ folder
npm run preview    # test the built site locally
```
Upload `dist/` to GitHub Pages, Netlify, Vercel, or run `firebase deploy` (Firebase Hosting, uses `dist`). Add your final domain to Firebase Auth authorized domains.

## One-time Firebase setup (project cakehub-86ee9)
1. Authentication > Sign-in method: turn on **Email/Password** and **Google**.
2. Authentication > Settings > Authorized domains: add your Codespaces domain (ends in `app.github.dev`) and your final website domain. Without this, login shows a "not allowed" message.
3. Firestore Database > Create database (production mode).
4. Firestore > Rules: paste `firestore.rules` and Publish (or `npx firebase-tools deploy --only firestore:rules`).
5. Open the site, **Log in > Continue with Google** with **patacjustinekeo@gmail.com**. The button changes to **Owner panel**. In Menu, tap **Load starter menu**, then edit prices.

## Notes
- The owner must sign in with Google (verified email). The rules only trust the verified owner email.
- Chat photos are shrunk in the browser and saved in Firestore, so paid Firebase Storage is not needed.
- Edit `js/config.js` for phone, address, hours, prices and cake options.
- Add a new page: create `name.html` in the root; Vite picks it up automatically.
